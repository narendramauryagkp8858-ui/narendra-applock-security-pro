# Narendra AppLock Security Pro
**Developed & Branded by Narendra Maurya**  
Version 3.2.0 (Build 32) · Minimum SDK 26 · Target SDK 35

## Project repair notes
This archive has been repaired for Android Studio project import: Gradle plugin versions are explicit, missing ViewBinding layouts and Android resources are included, and release signing no longer contains a hard-coded password. Existing package names, app identity, version, and Kotlin feature source files are retained.

## Build requirements
- Android Studio Ladybug or newer
- JDK 17
- Android SDK Platform 35 and Build Tools 35
- Internet access on first Gradle sync to download dependencies

## Build a debug APK
Open this folder in Android Studio, allow Gradle Sync to finish, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Or run `gradle assembleDebug` from the project directory if Gradle 8.7 is installed.

APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Sign a release build
For security, no signing key or password is bundled. Set these environment variables before running `gradle assembleRelease` or `gradle bundleRelease`:
- `NARENDRA_KEYSTORE_PATH`
- `NARENDRA_KEYSTORE_PASSWORD`
- `NARENDRA_KEY_ALIAS`
- `NARENDRA_KEY_PASSWORD`

Without these values, Gradle can assemble an unsigned release artifact; sign it with your own private keystore before distribution. Never share your keystore or passwords.

## Important Android platform limitations
App monitoring requires the user to grant Usage Access and may be restricted by battery/background policies. App cloning is not universally available to ordinary third-party apps. Device Admin can warn on deactivation but cannot guarantee uninstall prevention. Intruder camera capture requires camera permission and a foreground, lifecycle-bound activity; this source does not implement an invisible/background camera service.

© 2026 Narendra Maurya.
