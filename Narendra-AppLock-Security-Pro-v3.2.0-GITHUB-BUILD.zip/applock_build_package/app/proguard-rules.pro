# Keep Android components referenced from AndroidManifest.xml.
-keep public class com.narendramaurya.applockpro.AppLockApplication { *; }
-keep public class com.narendramaurya.applockpro.MainActivity { *; }
-keep public class com.narendramaurya.applockpro.ui.LockScreenActivity { *; }
-keep public class com.narendramaurya.applockpro.service.AppLockForegroundService { *; }
-keep public class com.narendramaurya.applockpro.receiver.** { *; }

# Preserve CameraX callback implementations and AndroidX Biometric integration.
-keep class androidx.camera.** { *; }
-keep class androidx.biometric.** { *; }
