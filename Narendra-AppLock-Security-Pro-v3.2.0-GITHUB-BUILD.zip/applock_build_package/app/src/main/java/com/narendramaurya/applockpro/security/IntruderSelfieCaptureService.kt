package com.narendramaurya.applockpro.security

import android.content.Context
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * CameraX-based Silent Front-Camera Capture for Intruder Detection.
 * Complies with Android privacy standards and executes transparently.
 * Developed by Narendra Maurya.
 */
object IntruderSelfieCaptureService {

    private const val TAG = "IntruderSelfie"

    fun captureSilentSnapshot(
        context: Context,
        targetApp: String,
        attemptedCode: String
    ) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        val executor = ContextCompat.getMainExecutor(context)

        cameraProviderFuture.addListener({
            try {
                val cameraProvider = cameraProviderFuture.get()
                val imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()

                val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA

                if (context is LifecycleOwner) {
                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(
                        context,
                        cameraSelector,
                        imageCapture
                    )

                    val photosDir = File(context.filesDir, "intruder_photos").apply { mkdirs() }
                    val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                    val photoFile = File(photosDir, "INTRUDER_${timeStamp}.jpg")

                    val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

                    imageCapture.takePicture(
                        outputOptions,
                        executor,
                        object : ImageCapture.OnImageSavedCallback {
                            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                                Log.i(TAG, "Intruder snapshot saved: ${photoFile.absolutePath}")
                                recordIntruderLog(context, targetApp, attemptedCode, photoFile.absolutePath)
                                cameraProvider.unbindAll()
                            }

                            override fun onError(exc: ImageCaptureException) {
                                Log.e(TAG, "Photo capture failed: ${exc.message}", exc)
                                cameraProvider.unbindAll()
                            }
                        }
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error initializing CameraX silent capture", e)
            }
        }, executor)
    }

    private fun recordIntruderLog(context: Context, app: String, code: String, filePath: String) {
        // Save to SQLite / Room encrypted database
    }
}
