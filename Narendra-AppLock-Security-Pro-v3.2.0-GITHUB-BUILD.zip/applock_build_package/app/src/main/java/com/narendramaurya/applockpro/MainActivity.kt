package com.narendramaurya.applockpro

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import com.narendramaurya.applockpro.databinding.ActivityMainBinding
import com.narendramaurya.applockpro.service.AppLockForegroundService

/**
 * Main Management Dashboard for Narendra AppLock Security Pro.
 * Developed by Narendra Maurya.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        verifyAndRequestRequiredPermissions()
        startSecurityService()
    }

    private fun setupUI() {
        binding.tvAppName.text = getString(R.string.app_name)
        binding.tvDeveloper.text = getString(R.string.developer_credit)
        
        // Navigation listener and tab switches implemented in layout
    }

    private fun verifyAndRequestRequiredPermissions() {
        // 1. Overlay Permission (SYSTEM_ALERT_WINDOW)
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }

        // 2. Usage Stats Access (PACKAGE_USAGE_STATS)
        if (!hasUsageStatsPermission()) {
            val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            startActivity(intent)
        }
    }

    private fun hasUsageStatsPermission(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                packageName
            )
        } else {
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun startSecurityService() {
        val intent = Intent(this, AppLockForegroundService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }
}
