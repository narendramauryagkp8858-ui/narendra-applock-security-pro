package com.narendramaurya.applockpro.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.narendramaurya.applockpro.AppLockApplication
import com.narendramaurya.applockpro.MainActivity
import com.narendramaurya.applockpro.R
import com.narendramaurya.applockpro.ui.LockScreenActivity

/**
 * Continuous Surveillance Foreground Service for Narendra AppLock Security Pro.
 * Intercepts foreground app changes and spawns LockScreenActivity.
 */
class AppLockForegroundService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var lastForegroundPackage: String = ""
    private var isLockedScreenVisible = false
    private val checkIntervalMs = 200L

    private val surveillanceRunnable = object : Runnable {
        override fun run() {
            checkForegroundApp()
            handler.postDelayed(this, checkIntervalMs)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildForegroundNotification())
        handler.post(surveillanceRunnable)
        return START_STICKY
    }

    private fun checkForegroundApp() {
        val currentPackage = getTopPackageName()
        if (currentPackage.isNotEmpty() && currentPackage != lastForegroundPackage) {
            lastForegroundPackage = currentPackage

            // Avoid locking Narendra AppLock itself or the lock overlay
            if (currentPackage != packageName) {
                if (isPackageLocked(currentPackage)) {
                    launchLockOverlay(currentPackage)
                }
            }
        }
    }

    private fun isPackageLocked(pkg: String): Boolean {
        val prefs = getSharedPreferences("narendra_locked_apps", Context.MODE_PRIVATE)
        return prefs.getBoolean("lock_$pkg", false)
    }

    private fun launchLockOverlay(targetPackage: String) {
        val lockIntent = Intent(this, LockScreenActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra(LockScreenActivity.EXTRA_PACKAGE_NAME, targetPackage)
        }
        startActivity(lockIntent)
    }

    private fun getTopPackageName(): String {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val time = System.currentTimeMillis()
        val usageEvents = usm.queryEvents(time - 1000 * 2, time)
        val event = UsageEvents.Event()
        var lastPkg = ""
        while (usageEvents.hasNextEvent()) {
            usageEvents.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                lastPkg = event.packageName
            }
        }
        return lastPkg
    }

    private fun buildForegroundNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, AppLockApplication.CHANNEL_ID_SECURITY)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_desc))
            .setSmallIcon(R.drawable.ic_shield_security)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(surveillanceRunnable)
    }

    companion object {
        private const val NOTIFICATION_ID = 8858
    }
}
