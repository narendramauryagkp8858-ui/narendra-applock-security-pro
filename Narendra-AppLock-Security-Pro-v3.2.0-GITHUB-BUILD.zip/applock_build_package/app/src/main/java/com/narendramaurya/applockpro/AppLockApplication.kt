package com.narendramaurya.applockpro

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.narendramaurya.applockpro.security.VaultEncryptionManager

/**
 * Application entry point for Narendra AppLock Security Pro.
 * Initialized by Narendra Maurya.
 */
class AppLockApplication : Application() {

    companion object {
        const val CHANNEL_ID_SECURITY = "narendra_security_channel"
        const val CHANNEL_NAME_SECURITY = "Security Surveillance Shield"
        lateinit var instance: AppLockApplication
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        // Initialize Android Keystore AES-256 Engine
        VaultEncryptionManager.initialize(this)

        // Create high-importance notification channel for foreground service
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID_SECURITY,
                CHANNEL_NAME_SECURITY,
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Monitors app openings and protects unauthorized access."
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }
}
