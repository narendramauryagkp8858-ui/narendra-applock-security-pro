package com.narendramaurya.applockpro.clone

import android.content.Context
import android.os.Process
import android.os.UserHandle
import android.os.UserManager

/**
 * Application Virtualization & Work Profile Sandboxing Engine.
 * Enables dual instances of messaging and social applications.
 * Developed by Narendra Maurya.
 */
object AppCloneManager {

    data class ClonedAppInfo(
        val packageName: String,
        val appName: String,
        val instanceId: Int,
        val isolatedStoragePath: String,
        val isRunning: Boolean
    )

    fun getSupportedCloningApps(): List<String> {
        return listOf(
            "com.whatsapp",
            "com.instagram.android",
            "com.facebook.katana",
            "org.telegram.messenger",
            "com.snapchat.android"
        )
    }

    fun isDeviceCloningSupported(context: Context): Boolean {
        val userManager = context.getSystemService(Context.USER_SERVICE) as? UserManager
        return userManager?.isSystemUser == true
    }
}
