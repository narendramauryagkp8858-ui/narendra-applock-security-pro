package com.narendramaurya.applockpro.receiver

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.narendramaurya.applockpro.R

/**
 * Device Administrator Policy Receiver for Narendra AppLock Security Pro.
 * Provides Anti-Uninstall Defense and Tamper Prevention.
 * Developed by Narendra Maurya.
 */
class DeviceAdminSecurityReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Toast.makeText(
            context,
            context.getString(R.string.device_admin_enabled_toast),
            Toast.LENGTH_LONG
        ).show()
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence? {
        // Warning shown when a user or intruder attempts to deactivate Device Admin
        return context.getString(R.string.device_admin_disable_warning)
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Toast.makeText(
            context,
            context.getString(R.string.device_admin_disabled_alert),
            Toast.LENGTH_LONG
        ).show()
    }
}
