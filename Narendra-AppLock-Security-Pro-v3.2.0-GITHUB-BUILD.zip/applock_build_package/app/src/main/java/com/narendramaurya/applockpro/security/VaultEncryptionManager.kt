package com.narendramaurya.applockpro.security

import android.content.Context
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKey
import java.io.File
import java.io.InputStream
import java.io.OutputStream

/**
 * Military-grade AES-256-GCM Private File Vault Engine.
 * Backed by Android Keystore hardware security module.
 * Developed by Narendra Maurya.
 */
object VaultEncryptionManager {

    private lateinit var masterKey: MasterKey

    fun initialize(context: Context) {
        masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .setRequestStrongBoxBacked(false) // Use Android Keystore; StrongBox is optional and device-dependent
            .build()
    }

    /**
     * Encrypt a sensitive file into the private vault directory.
     */
    fun encryptFileToVault(
        context: Context,
        sourceStream: InputStream,
        destinationVaultFile: File
    ): Boolean {
        return try {
            val encryptedFile = EncryptedFile.Builder(
                context,
                destinationVaultFile,
                masterKey,
                EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
            ).build()

            encryptedFile.openFileOutput().use { outputStream: OutputStream ->
                sourceStream.copyTo(outputStream)
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /**
     * Decrypt an encrypted vault file for viewing or export.
     */
    fun decryptVaultFile(
        context: Context,
        encryptedVaultFile: File,
        targetExportStream: OutputStream
    ): Boolean {
        return try {
            val encryptedFile = EncryptedFile.Builder(
                context,
                encryptedVaultFile,
                masterKey,
                EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
            ).build()

            encryptedFile.openFileInput().use { inputStream: InputStream ->
                inputStream.copyTo(targetExportStream)
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
