package com.narendramaurya.applockpro.ui

import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import com.narendramaurya.applockpro.R
import com.narendramaurya.applockpro.databinding.ActivityLockScreenBinding
import com.narendramaurya.applockpro.security.IntruderSelfieCaptureService

/**
 * Android Lock Screen Window Overlay with PIN, Pattern, and Biometrics.
 * Designed by Narendra Maurya.
 */
class LockScreenActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLockScreenBinding
    private var failedAttempts = 0
    private var targetPackage: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLockScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        targetPackage = intent.getStringExtra(EXTRA_PACKAGE_NAME) ?: ""

        setupBiometricPrompt()
        setupPinInputs()
        setupCamouflageCrashScreen()
    }

    private fun setupBiometricPrompt() {
        val executor = ContextCompat.getMainExecutor(this)
        val biometricPrompt = BiometricPrompt(
            this,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    unlockTargetApp()
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    onIncorrectAttempt("Biometric mismatch")
                }
            }
        )

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.biometric_prompt_title))
            .setSubtitle(getString(R.string.biometric_prompt_subtitle))
            .setNegativeButtonText(getString(R.string.use_pin_instead))
            .build()

        binding.btnFingerprint.setOnClickListener {
            biometricPrompt.authenticate(promptInfo)
        }
    }

    private fun setupPinInputs() {
        // Keypad buttons 0-9, delete, submit
        binding.btnSubmitPin.setOnClickListener {
            val enteredPin = binding.etPinInput.text.toString()
            if (verifyPin(enteredPin)) {
                unlockTargetApp()
            } else {
                onIncorrectAttempt(enteredPin)
            }
        }
    }

    private fun verifyPin(pin: String): Boolean {
        val prefs = getSharedPreferences("narendra_security_prefs", MODE_PRIVATE)
        val masterPin = prefs.getString("master_pin", "1234")
        return pin == masterPin
    }

    private fun onIncorrectAttempt(attemptedCode: String) {
        failedAttempts++
        Toast.makeText(this, getString(R.string.auth_failed), Toast.LENGTH_SHORT).show()

        // Trigger Silent Intruder Selfie on threshold
        val threshold = getSharedPreferences("narendra_security_prefs", MODE_PRIVATE)
            .getInt("intruder_threshold", 2)

        if (failedAttempts >= threshold) {
            IntruderSelfieCaptureService.captureSilentSnapshot(
                context = this,
                targetApp = targetPackage,
                attemptedCode = attemptedCode
            )
        }

        // Lockout timer on 5 consecutive fails
        if (failedAttempts >= 5) {
            triggerBruteForceLockout(30)
        }
    }

    private fun triggerBruteForceLockout(seconds: Int) {
        binding.layoutPinKeypad.visibility = View.GONE
        binding.tvLockoutNotice.visibility = View.VISIBLE

        object : CountDownTimer(seconds * 1000L, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                binding.tvLockoutNotice.text = getString(
                    R.string.lockout_countdown,
                    millisUntilFinished / 1000
                )
            }

            override fun onFinish() {
                binding.layoutPinKeypad.visibility = View.VISIBLE
                binding.tvLockoutNotice.visibility = View.GONE
                failedAttempts = 0
            }
        }.start()
    }

    private fun setupCamouflageCrashScreen() {
        // If camouflage fake crash is enabled for this app:
        // Shows fake system crash dialog. Secret double-tap reveals the real lock screen.
    }

    private fun unlockTargetApp() {
        finish()
    }

    override fun onBackPressed() {
        // Minimize to home screen to prevent unauthorized bypass
        val homeIntent = android.content.Intent(android.content.Intent.ACTION_MAIN).apply {
            addCategory(android.content.Intent.CATEGORY_HOME)
            flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(homeIntent)
        finish()
    }

    companion object {
        const val EXTRA_PACKAGE_NAME = "extra_target_package"
    }
}
